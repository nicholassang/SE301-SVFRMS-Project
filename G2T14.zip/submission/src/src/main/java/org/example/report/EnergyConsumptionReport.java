package org.example.report;

import java.time.LocalDate;

public class EnergyConsumptionReport implements Report {
    private final ReportDataSource dataSource;

    public EnergyConsumptionReport(ReportDataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public String generate() {
        StringBuilder report = new StringBuilder();

        report.append("\n==============================\n");
        report.append("== ENERGY CONSUMPTION REPORT =");
        report.append("\n==============================\n");
        report.append("Date: ").append(LocalDate.now()).append("\n\n");

        report.append("Total Energy Consumption: ")
                .append(dataSource.getTotalEnergyUsage())
                .append(" kWh\n");

        return report.toString();
    }

    @Override
    public String getFileName() {
        return "energy_consumption_report.txt";
    }
}
